This is a chatbot for customer service in mobile telecommunication. The chatbot was developed using the RASA library.

you need to have RASA and Duckling to run this app
